/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/17 00:51:03 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/17 04:34:03 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "sudoku.h"

int		is_possible(char **grid, int y, int x, char c)
{
	int		ix;
	int		iy;

	ix = 0;
	printf("IS THIS POSSIBLE? \tX = %d\tY = %d\tC = %s\n", x, y, &c);
	while (ix < 9)
	{
		if ((ix != x) && (grid[y][ix] == c))
			return (0);
		ix++;
	}
	iy = 0;
	while (iy < 9)
	{
		if ((iy != y) && (grid[iy][x] == c))
			return (0);
		iy++;
	}
	return (1);
}

int		sudo_solver(char **grid, int y, int x)
{
	char	c;

	c = '1';
	if (y == 9)
		return (1);
	if (x == 9)
	{
		x = 0;
		y++;
		return (sudo_solver(grid, y, x));
	}
	if (grid[y][x] != '.')
		return (sudo_solver(grid, y, x + 1));
	while (c <= '9')
	{
		if (is_possible(grid, y, x, c))
		{
			show_grid(grid);
			printf("YES\n");
			grid[y][x] = c;
			x++;
			if (sudo_solver(grid, y, x))
				return (1);
		}
		c++;
	}
	return (0);
}

char	**copy_grid(char **argv)
{
	char	**grid;
	int		x;
	int		y;

	y = 0;
	if (!(grid = (char**)malloc(sizeof(char*) * 10)))
		return (NULL);
	while (y < 9)
	{
		if (!(grid[y] = (char*)malloc(sizeof(char) * 10)))
			return (NULL);
		x = 0;
		while (x < 9)
		{
			if ((argv[y + 1][x] != '.') \
			&& ((argv[y + 1][x] > '9') 	\
			|| (argv[y + 1][x] < '1')))
				return (NULL);
			grid[y][x] = argv[y + 1][x];
			x++;
		}
		y++;
	}
	return (grid);
}

int		error(char *msg)
{
	int		i;

	i = 0;
	while (msg[i] != '\0')
	{
		write(1, &msg[i], 1);
		i++;
	}
	return (1);
}

void	show_grid(char **grid)
{
	int		x;
	int		y;

	y = 0;
	while (y < 9)
	{
		x = 0;
		while (x < 9)
		{
			write(1, &grid[y][x], 1);
			write(1, " ", 1);
			x++;
		}
		write(1, "\n", 1);
		y++;
	}
}

int		main(int argc, char **argv)
{
	char	**grid;

	if (argc != 10)
		return (error("Erreur\n"));
	if (!(grid = copy_grid(argv)))
		return (error("Erreur\n"));
	show_grid(grid);
	if (!(sudo_solver(grid, 0, 0)))
		return (error("Erreur\n"));
	show_grid(grid);
	return (0);
}
