/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 18:19:58 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/16 22:51:06 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		next_word(char *sentence, int i)
{
	while ((sentence[i] == '\t')
		|| (sentence[i] == '\n')
		|| (sentence[i] == ' '))
		i++;
	if (sentence[i] == '\0')
		return (0);
	else
		return (i);
}

int		word_copy(char *dest, char *sentence, int i)
{
	int		i_d;

	i_d = 0;
	while ((sentence[i] != '\t')
		&& (sentence[i] != '\0')
		&& (sentence[i] != '\n')
		&& (sentence[i] != ' '))
		dest[i_d++] = sentence[i++];
	dest[i_d] = '\0';
	if (sentence[i] == '\0')
		return (0);
	else
		return (i);
}

int		count_words(char *str)
{
	int		i;
	int		count;

	i = 0;
	count = 0;
	while (str[i] != '\0')
	{
		while ((str[i] == '\t')
			|| (str[i] == '\n')
			|| (str[i] == ' '))
			i++;
		if (str[i] != '\0')
			count++;
		while ((str[i] != '\t')
			&& (str[i] != '\n')
			&& (str[i] != '\0')
			&& (str[i] != ' '))
			i++;
	}
	return (count);
}

int		word_len(char *str)
{
	int		i;

	i = 0;
	while ((str[i] != '\t')
		&& (str[i] != '\0')
		&& (str[i] != '\n')
		&& (str[i] != ' '))
		i++;
	return (i);
}

char	**ft_split_whitespaces(char *str)
{
	int		i_t;
	int		i_s;
	int		word_count;
	char	**word_tab;

	i_t = 0;
	i_s = 0;
	word_count = count_words(str);
	word_tab = (char**)malloc(sizeof(char*) * (word_count + 1));
	if (word_tab <= 0)
		return (NULL);
	while (i_t < word_count)
	{
		i_s = next_word(str, i_s);
		word_tab[i_t] = (char*)malloc(sizeof(char) * (word_len(&str[i_s]) + 1));
		i_s = word_copy(word_tab[i_t], str, i_s);
		i_t++;
	}
	word_tab[i_t] = 0;
	return (word_tab);
}
