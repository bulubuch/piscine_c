/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_param_to_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/16 18:06:15 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/16 22:51:03 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_par.h"

void				stock_param(char *par, struct s_stock_par *new_par)
{
	int					i;

	i = 0;
	while (par[i] != '\0')
		i++;
	new_par->size_param = i;
	new_par->str = par;
	if (!(new_par->copy = (char*)malloc(sizeof(char) * (i + 1))))
		return ;
	i = 0;
	while (par[i] != '\0')
	{
		new_par->copy[i] = par[i];
		i++;
	}
	new_par->copy[i] = '\0';
	new_par->tab = ft_split_whitespaces(par);
	return ;
}

struct s_stock_par	*ft_param_to_tab(int ac, char **av)
{
	struct s_stock_par	*param_tab;
	int					i;

	if (!(param_tab = (struct s_stock_par*)malloc(sizeof(struct s_stock_par) \
		* (ac + 1))))
		return (NULL);
	i = 0;
	while (i < ac)
	{
		stock_param(av[i], &param_tab[i]);
		i++;
	}
	param_tab[i].str = 0;
	return (param_tab);
}
