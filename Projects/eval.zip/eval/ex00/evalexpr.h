/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   evalexpr.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/22 23:02:17 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/23 06:42:47 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EVALEXPR_H
# define EVALEXPR_H

# include <unistd.h>
# include <stdlib.h>

# define END_OF_LINE		0
# define NUMBER				1
# define SYMBOL 			2
# define ILLEGAL_EXPR_MSG	"Illegal character in expression.\n"
# define NUMBER_EXPEXTED	"Number is expected.\n"
# define BAD_EXPRESSION		"Bad expression\n"
# define MALLOC_ERROR_MSG	"malloc() failed to allocate enough memory\n"

typedef struct	s_expr
{
	char	*str;
	int		pos;
	int		lexem_type;
	char	symbol;
	char	number[32];
}				t_expr;

int				is_number(t_expr *expr);
int				display_error(char *msg);
int				is_symbol(t_expr *expr);
void			next_lexem(t_expr *expr);
int				high(t_expr *expr);
int				med(t_expr *expr);
int				low(t_expr *expr);
int				number(t_expr *expr);
int				eval_expr(char *str);
int				ft_atoi(char *str);
void			ft_putchar(char c);
void			ft_putnbr(int nb);
void			ft_putchar(char c);

#endif
