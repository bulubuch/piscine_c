/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   is_number.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/23 05:52:57 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/23 06:34:40 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "evalexpr.h"

int		is_number(t_expr *expr)
{
	int	i;

	i = 0;
	if ((expr->str[expr->pos] >= '0') && (expr->str[expr->pos] <= '9'))
	{
		while ((expr->str[expr->pos] >= '0') && (expr->str[expr->pos] <= '9'))
			expr->number[i++] = expr->str[expr->pos++];
		expr->number[i] = '\0';
		return (1);
	}
	return (0);
}
