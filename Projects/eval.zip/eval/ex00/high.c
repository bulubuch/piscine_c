/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   high.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/23 05:55:45 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/23 06:41:34 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "evalexpr.h"

int		high(t_expr *expr)
{
	int		nb;

	if ((expr->lexem_type == SYMBOL) && (expr->symbol == '('))
	{
		next_lexem(expr);
		nb = low(expr);
		if (!((expr->lexem_type == SYMBOL) && (expr->symbol == ')')))
			display_error(BAD_EXPRESSION);
		else
			next_lexem(expr);
	}
	else
		nb = number(expr);
	return (nb);
}
