/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/23 05:59:02 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/23 06:41:37 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "evalexpr.h"

int		display_error(char *msg)
{
	int		i;

	i = 0;
	while (msg[i] != '\0')
		write(2, &msg[i++], 1);
	return (1);
}

int		eval_expr(char *str)
{
	t_expr	*expr;
	int		result;

	if (!(expr = (t_expr*)malloc(sizeof(t_expr))))
		return (display_error(MALLOC_ERROR_MSG));
	expr->str = str;
	expr->pos = 0;
	expr->lexem_type = -1;
	expr->symbol = -1;
	result = 0;
	next_lexem(expr);
	if (expr->lexem_type != END_OF_LINE)
	{
		result = low(expr);
		if (expr->lexem_type != END_OF_LINE)
			return (result);
	}
	return (result);
}

int		main(int ac, char **av)
{
	if (ac > 1)
	{
		ft_putnbr(eval_expr(av[1]));
		ft_putchar('\n');
	}
	return (0);
}
