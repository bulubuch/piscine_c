/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   number.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/23 05:58:15 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/23 06:41:35 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "evalexpr.h"

int		number(t_expr *expr)
{
	int		nb;

	if (expr->lexem_type != NUMBER)
		display_error(NUMBER_EXPEXTED);
	nb = ft_atoi(expr->number);
	next_lexem(expr);
	return (nb);
}
