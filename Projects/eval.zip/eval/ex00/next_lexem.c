/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   next_lexem.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/23 05:55:09 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/23 06:41:36 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "evalexpr.h"

void	next_lexem(t_expr *expr)
{
	while ((expr->str[expr->pos] == ' ') || (expr->str[expr->pos] == '\t'))
		expr->pos++;
	if (expr->str[expr->pos] == '\0')
		expr->lexem_type = END_OF_LINE;
	else
	{
		if (is_number(expr))
			expr->lexem_type = NUMBER;
		else if (is_symbol(expr))
			expr->lexem_type = SYMBOL;
		else
			display_error(ILLEGAL_EXPR_MSG);
	}
	return ;
}
