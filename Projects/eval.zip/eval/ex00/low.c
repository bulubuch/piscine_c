/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   low.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/23 05:56:49 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/23 06:42:13 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "evalexpr.h"

int		low(t_expr *expr)
{
	int		nb1;
	int		nb2;
	char	op;

	nb1 = med(expr);
	while ((expr->lexem_type == SYMBOL)
			&& ((expr->symbol == '+')
			|| (expr->symbol == '-')))
	{
		op = expr->symbol;
		next_lexem(expr);
		nb2 = med(expr);
		if (op == '+')
			nb1 = nb1 + nb2;
		if (op == '-')
			nb1 = nb1 - nb2;
	}
	return (nb1);
}
