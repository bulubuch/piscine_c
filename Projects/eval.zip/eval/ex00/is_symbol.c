/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   is_symbol.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbuch <mbuch@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/23 05:53:49 by mbuch             #+#    #+#             */
/*   Updated: 2016/07/23 06:34:41 by mbuch            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "evalexpr.h"

int		is_symbol(t_expr *expr)
{
	if ((expr->str[expr->pos] == '(') || (expr->str[expr->pos] == ')')
		|| (expr->str[expr->pos] == '+') || (expr->str[expr->pos] == '-')
		|| (expr->str[expr->pos] == '*') || (expr->str[expr->pos] == '/')
		|| (expr->str[expr->pos] == '%'))
	{
		expr->symbol = expr->str[expr->pos];
		expr->pos++;
		return (1);
	}
	return (0);
}
